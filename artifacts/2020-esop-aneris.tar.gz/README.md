# The Aneris Coq Development

The development is known to compile with

 - Coq 8.9.1
 - [Iris 3.2.0](https://gitlab.mpi-sws.org/iris/iris/tree/iris-3.2.0) (commit e1f6efa0)
 - [std++ 1.2.1](https://gitlab.mpi-sws.org/iris/stdpp/tree/coq-stdpp-1.2.1) (commit 75435486)

All dependencies can be installed using opam by running the command `make
build-dep`. The whole development can be built using `make -j [num CPU cores]`

## Theory of Aneris

The theory of Aneris can be found in the directory [dist_lang](dist_lang). All
examples and case studies are found in the [examples](examples) folder.

For a browser-based overview of the whole Coq formalization see
[index.html](index.hml).
